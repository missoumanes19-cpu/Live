import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';

const Map<String, String> _en = {
  'السيرفر': 'Server', 'البث المباشر': 'Live TV', 'الأفلام': 'Movies',
  'المسلسلات': 'Series', 'المفضلة': 'Favorites', 'مشاهدة لاحقاً': 'History',
  'الإعدادات': 'Settings', 'ابحث عن محتوى...': 'Search...', 'قناة': 'channels',
  'اللغة': 'Language', 'المشغّل': 'Player', 'وضع فك التشفير': 'Decoder mode',
  'تلقائي': 'Auto', 'عتاد (Hardware)': 'Hardware', 'برمجي (Software)': 'Software',
  'نسبة العرض الافتراضية': 'Default aspect ratio', 'احتواء': 'Fit',
  'ملء الشاشة': 'Fill screen', 'تمديد': 'Stretch', 'الحجم الأصلي': 'Original',
  'حجم الذاكرة المؤقتة': 'Buffer size', 'التحديث التلقائي من GitHub': 'Auto-update from GitHub',
  'الرقابة الأبوية': 'Parental control', 'مسح الذاكرة المؤقتة': 'Clear cache',
  'تم مسح الذاكرة المؤقتة': 'Cache cleared', 'عام': 'General', 'حول التطبيق': 'About',
  'ANES TV • السيرفرات': 'ANES TV • Servers', 'اختر مصدر القنوات': 'Choose a channel source',
  'ملف M3U': 'M3U', 'السيرفر الأونلاين • GitHub': 'Online server • GitHub',
  'اتصال وتحميل القنوات': 'Connect and load channels', 'جارٍ الاتصال...': 'Connecting...',
  'فشل الاتصال': 'Connection failed', 'رابط السيرفر / Host': 'Server URL / Host',
  'اسم المستخدم': 'Username', 'كلمة المرور': 'Password', 'رابط M3U': 'M3U link',
  'اختيار ملف M3U / M3U8': 'Pick M3U / M3U8 file', 'رابط GitHub Raw لملف JSON': 'GitHub Raw JSON link',
  'حفظ وتحديث الآن': 'Save and update now', 'آخر تحديث': 'Last update',
  'لم يتم التحديث بعد': 'Not updated yet', 'تم تحديث القنوات من GitHub': 'Channels updated from GitHub',
  'إعادة المحاولة': 'Retry', 'تبديل وضع فك التشفير': 'Switch decoder',
  'تغيير نسبة العرض': 'Change aspect ratio', 'المصدر الحالي': 'Current source',
  'لا يوجد مصدر': 'No source yet', 'متصل': 'Connected',
  'الصوت والترجمة': 'Audio & subtitles', 'الصوت': 'Audio', 'الترجمة': 'Subtitles',
  'إيقاف': 'Off', 'نسبة العرض': 'Aspect ratio', 'مؤقّت النوم': 'Sleep timer',
  'يتوفر تحديث للتطبيق': 'App update available', 'حدّث التطبيق إلى آخر إصدار': 'Please update the app',
  'أضيفت إلى المفضلة': 'Added to favorites', 'أزيلت من المفضلة': 'Removed from favorites',
  'تشخيص الاتصال': 'Connection diagnostics', 'إخفاء تصنيفات': 'Hide categories',
  'السيرفرات المحفوظة': 'Saved servers', 'بحث شامل': 'Search everything',
  'زمن الاستجابة': 'Response time', 'حالة الحساب': 'Account status',
  'تاريخ الانتهاء': 'Expiry date', 'الاتصالات المتزامنة': 'Connections',
  'اختبار': 'Run test', 'غير محدود': 'Unlimited', 'الإصدار': 'Version',
  'اتصال': 'Connect', 'قطع الاتصال': 'Disconnect', 'غير متصل': 'Disconnected',
  'تحديث الآن': 'Update now', 'تحديث تلقائي': 'Auto update', 'الكل': 'All',
  'قائمة القنوات': 'Channels', 'ابحث في القنوات والأفلام والمسلسلات': 'Search channels, movies, series',
  'الرئيسية': 'Home',
  'حساب': 'Account',
  'إعادة تحميل': 'Reload',
  'خروج': 'Exit',
  'تغيير القائمة': 'Change list',
  'شكل الواجهة': 'Interface style',
  'كلاسيكي': 'Classic',
  'عصري': 'Modern',
  'المشغّل الافتراضي': 'Default player',
  'مشغّل داخلي': 'Built-in player',
  'اختيار تطبيق': 'Choose app',
  'حزمة تطبيق مخصص': 'Custom app package',
  'المشغّل الخارجي غير مثبّت، سيُستخدم المشغّل الداخلي': 'External player not installed, using the built-in player',
  'فتح بواسطة': 'Open with',
  'تحقق من التحديث': 'Check for update',
  'أنت تستخدم آخر إصدار': 'You have the latest version',
  'تحديث متوفر': 'Update available',
  'تنزيل': 'Download',
  'نسخ احتياطي': 'Backup',
  'تصدير إلى الحافظة': 'Export to clipboard',
  'استيراد من الحافظة': 'Import from clipboard',
  'تم النسخ': 'Copied',
  'تم الاستيراد، أعد تشغيل التطبيق': 'Imported, please restart the app',
  'آخر قناة': 'Last channel',
  'تشغيل': 'Play',
  'أضف للمفضلة': 'Add to favorites',
  'إزالة من المفضلة': 'Remove from favorites',
  'مشاهدة حديثاً': 'Recently watched',
  'اختر قناة': 'Select a channel',
  'التالي': 'Next',
  'التنزيلات': 'Downloads',
  'تحميل': 'Download',
  'تحميل الكل': 'Download all',
  'بدأ التحميل': 'Download started',
  'هذا الرابط لا يدعم التحميل': 'This link cannot be downloaded',
  'جاهز بدون إنترنت': 'Ready offline',
  'في الانتظار': 'Queued',
  'فشل': 'Failed',
  'متوقف': 'Paused',
  'حذف التنزيل؟': 'Delete download?',
  'إلغاء': 'Cancel',
  'حذف': 'Delete',
  'لا توجد تنزيلات بعد. اضغط تحميل على أي فيلم أو حلقة.': 'No downloads yet. Tap Download on any movie or episode.',
  'إضافة ملف ترجمة': 'Add subtitle file',
  'صيغة الترجمة غير مدعومة': 'Unsupported subtitle format',
  'تمت إضافة الترجمة': 'Subtitle added',
  'تعذر تحميل الترجمة': 'Could not load subtitle',
  'تحميل للمشاهدة بدون إنترنت': 'Download for offline viewing',
  'تم نسخ الرابط. الصقه داخل المشغّل الخارجي لتشغيله': 'Link copied. Paste it in the external player to play',
  'التخزين المؤقت قبل التشغيل': 'Pre-buffer before playing',
  'جارٍ التخزين': 'Buffering',
  'تعريب الترجمة': 'Translate subtitles to Arabic',
  'إيقاف التعريب': 'Stop translation',
  'تعريب الترجمة: تشغيل': 'Subtitle translation: on',
  'لا توجد ترجمة في هذا الفيديو — أضف ملف ترجمة': 'No subtitles in this video — add a subtitle file',
  'حجم الترجمة وألوانها': 'Subtitle size & colors',
  'لون النص': 'Text color',
  'الخلفية': 'Background',
  'نص تجريبي': 'Sample text',
};

const Map<String, String> _fr = {
  'السيرفر': 'Serveur',
  'البث المباشر': 'Chaînes',
  'الأفلام': 'Films',
  'المسلسلات': 'Séries',
  'المفضلة': 'Favoris',
  'مشاهدة لاحقاً': 'Historique',
  'الإعدادات': 'Paramètres',
  'ابحث عن محتوى...': 'Rechercher...',
  'قناة': 'chaînes',
  'اللغة': 'Langue',
  'المشغّل': 'Lecteur',
  'وضع فك التشفير': 'Mode de décodage',
  'تلقائي': 'Auto',
  'عتاد (Hardware)': 'Matériel',
  'برمجي (Software)': 'Logiciel',
  'نسبة العرض الافتراضية': 'Format d\'image par défaut',
  'احتواء': 'Ajuster',
  'ملء الشاشة': 'Plein écran',
  'تمديد': 'Étirer',
  'الحجم الأصلي': 'Taille originale',
  'حجم الذاكرة المؤقتة': 'Taille du tampon',
  'التحديث التلقائي من GitHub': 'Mise à jour auto depuis GitHub',
  'الرقابة الأبوية': 'Contrôle parental',
  'مسح الذاكرة المؤقتة': 'Vider le cache',
  'تم مسح الذاكرة المؤقتة': 'Cache vidé',
  'عام': 'Général',
  'حول التطبيق': 'À propos',
  'ANES TV • السيرفرات': 'ANES TV • Serveurs',
  'اختر مصدر القنوات': 'Choisissez la source',
  'ملف M3U': 'M3U',
  'السيرفر الأونلاين • GitHub': 'Serveur en ligne • GitHub',
  'اتصال وتحميل القنوات': 'Se connecter et charger',
  'جارٍ الاتصال...': 'Connexion...',
  'فشل الاتصال': 'Échec de la connexion',
  'رابط السيرفر / Host': 'URL du serveur / Hôte',
  'اسم المستخدم': 'Nom d\'utilisateur',
  'كلمة المرور': 'Mot de passe',
  'رابط M3U': 'Lien M3U',
  'اختيار ملف M3U / M3U8': 'Choisir un fichier M3U / M3U8',
  'رابط GitHub Raw لملف JSON': 'Lien GitHub Raw du JSON',
  'حفظ وتحديث الآن': 'Enregistrer et actualiser',
  'آخر تحديث': 'Dernière mise à jour',
  'لم يتم التحديث بعد': 'Pas encore mis à jour',
  'تم تحديث القنوات من GitHub': 'Chaînes mises à jour depuis GitHub',
  'إعادة المحاولة': 'Réessayer',
  'تبديل وضع فك التشفير': 'Changer le décodage',
  'تغيير نسبة العرض': 'Changer le format d\'image',
  'المصدر الحالي': 'Source actuelle',
  'لا يوجد مصدر': 'Aucune source',
  'متصل': 'Connecté',
  'الصوت والترجمة': 'Audio et sous-titres',
  'الصوت': 'Audio',
  'الترجمة': 'Sous-titres',
  'إيقاف': 'Désactivé',
  'نسبة العرض': 'Format d\'image',
  'مؤقّت النوم': 'Minuterie de veille',
  'يتوفر تحديث للتطبيق': 'Mise à jour de l\'application disponible',
  'حدّث التطبيق إلى آخر إصدار': 'Mettez l\'application à jour',
  'أضيفت إلى المفضلة': 'Ajouté aux favoris',
  'أزيلت من المفضلة': 'Retiré des favoris',
  'تشخيص الاتصال': 'Diagnostic de connexion',
  'إخفاء تصنيفات': 'Masquer des catégories',
  'السيرفرات المحفوظة': 'Serveurs enregistrés',
  'بحث شامل': 'Recherche globale',
  'زمن الاستجابة': 'Temps de réponse',
  'حالة الحساب': 'État du compte',
  'تاريخ الانتهاء': 'Date d\'expiration',
  'الاتصالات المتزامنة': 'Connexions simultanées',
  'اختبار': 'Tester',
  'غير محدود': 'Illimité',
  'الإصدار': 'Version',
  'اتصال': 'Connexion',
  'قطع الاتصال': 'Déconnexion',
  'غير متصل': 'Non connecté',
  'تحديث الآن': 'Actualiser',
  'تحديث تلقائي': 'Mise à jour auto',
  'الكل': 'Tout',
  'قائمة القنوات': 'Chaînes',
  'ابحث في القنوات والأفلام والمسلسلات': 'Rechercher chaînes, films, séries',
  'الرئيسية': 'Domicile',
  'حساب': 'Compte',
  'إعادة تحميل': 'Recharger',
  'خروج': 'Quitter',
  'تغيير القائمة': 'Changer de liste',
  'شكل الواجهة': 'Style d\'interface',
  'كلاسيكي': 'Classique',
  'عصري': 'Moderne',
  'المشغّل الافتراضي': 'Lecteur par défaut',
  'مشغّل داخلي': 'Lecteur intégré',
  'اختيار تطبيق': 'Choisir une appli',
  'حزمة تطبيق مخصص': 'Package d\'appli personnalisé',
  'المشغّل الخارجي غير مثبّت، سيُستخدم المشغّل الداخلي': 'Lecteur externe non installé, lecteur intégré utilisé',
  'فتح بواسطة': 'Ouvrir avec',
  'تحقق من التحديث': 'Vérifier la mise à jour',
  'أنت تستخدم آخر إصدار': 'Vous avez la dernière version',
  'تحديث متوفر': 'Mise à jour disponible',
  'تنزيل': 'Télécharger',
  'نسخ احتياطي': 'Sauvegarde',
  'تصدير إلى الحافظة': 'Exporter vers le presse-papiers',
  'استيراد من الحافظة': 'Importer depuis le presse-papiers',
  'تم النسخ': 'Copié',
  'تم الاستيراد، أعد تشغيل التطبيق': 'Importé, redémarrez l\'application',
  'آخر قناة': 'Dernière chaîne',
  'تشغيل': 'Lire',
  'أضف للمفضلة': 'Ajouter aux favoris',
  'إزالة من المفضلة': 'Retirer des favoris',
  'مشاهدة حديثاً': 'Vu récemment',
  'اختر قناة': 'Choisissez une chaîne',
  'التالي': 'Suivant',
  'التنزيلات': 'Téléchargements',
  'تحميل': 'Télécharger',
  'تحميل الكل': 'Tout télécharger',
  'بدأ التحميل': 'Téléchargement démarré',
  'هذا الرابط لا يدعم التحميل': 'Ce lien ne peut pas être téléchargé',
  'جاهز بدون إنترنت': 'Prêt hors ligne',
  'في الانتظار': 'En attente',
  'فشل': 'Échec',
  'متوقف': 'En pause',
  'حذف التنزيل؟': 'Supprimer le téléchargement ?',
  'إلغاء': 'Annuler',
  'حذف': 'Supprimer',
  'لا توجد تنزيلات بعد. اضغط تحميل على أي فيلم أو حلقة.': 'Aucun téléchargement. Appuyez sur Télécharger sur un film ou un épisode.',
  'إضافة ملف ترجمة': 'Ajouter un fichier de sous-titres',
  'صيغة الترجمة غير مدعومة': 'Format de sous-titres non pris en charge',
  'تمت إضافة الترجمة': 'Sous-titres ajoutés',
  'تعذر تحميل الترجمة': 'Impossible de charger les sous-titres',
  'تحميل للمشاهدة بدون إنترنت': 'Télécharger pour regarder hors ligne',
  'تم نسخ الرابط. الصقه داخل المشغّل الخارجي لتشغيله': 'Lien copié. Collez-le dans le lecteur externe pour lire',
  'التخزين المؤقت قبل التشغيل': 'Pré-chargement avant lecture',
  'جارٍ التخزين': 'Mise en mémoire tampon',
  'تعريب الترجمة': 'Traduire les sous-titres en arabe',
  'إيقاف التعريب': 'Arrêter la traduction',
  'تعريب الترجمة: تشغيل': 'Traduction des sous-titres : activée',
  'لا توجد ترجمة في هذا الفيديو — أضف ملف ترجمة': 'Aucun sous-titre dans cette vidéo — ajoutez un fichier',
  'حجم الترجمة وألوانها': 'Taille et couleurs des sous-titres',
  'لون النص': 'Couleur du texte',
  'الخلفية': 'Arrière-plan',
  'نص تجريبي': 'Texte de test',
};

String t(String ar) => AppSettings.lang == 'en' ? (_en[ar] ?? ar)
    : AppSettings.lang == 'fr' ? (_fr[ar] ?? _en[ar] ?? ar) : ar;

class AppSettings extends ChangeNotifier {
  static String lang = 'ar';
  Box get _b => Hive.box('settings');

  AppSettings() { lang = (_b.get('lang', defaultValue: 'ar') as String); }

  void setLanguage(String v) { lang = v; _b.put('lang', v); notifyListeners(); }

  String get decoder => _b.get('decoder', defaultValue: 'auto') as String; // auto | hw | sw
  void setDecoder(String v) { _b.put('decoder', v); notifyListeners(); }
  static String hwdec(String d) =>
      d == 'hw' ? 'mediacodec-copy' : d == 'sw' ? 'no' : 'auto-safe';

  int get fit => _b.get('fit', defaultValue: 0) as int; // 0..3
  void setFit(int v) { _b.put('fit', v); notifyListeners(); }

  double get subSize => (_b.get('subSize', defaultValue: 22.0) as num).toDouble();
  int get subColor => _b.get('subColor', defaultValue: 0xFFFFFFFF) as int;
  int get subBg => _b.get('subBg', defaultValue: 0x99000000) as int;
  void saveSubStyle(double size, int color, int bg) {
    _b.put('subSize', size); _b.put('subColor', color); _b.put('subBg', bg);
  }
  int get prebufferSec => _b.get('prebufferSec', defaultValue: 10) as int;
  void setPrebufferSec(int v) { _b.put('prebufferSec', v); notifyListeners(); }
  int get bufferMb => _b.get('bufferMb', defaultValue: 64) as int;
  void setBufferMb(int v) { _b.put('bufferMb', v); notifyListeners(); }

  Set<String> get hidden => Set<String>.from(
      (_b.get('hidden', defaultValue: <dynamic>[]) as List).map((e) => '$e'));
  void toggleHidden(String c) {
    final s = hidden;
    s.contains(c) ? s.remove(c) : s.add(c);
    _b.put('hidden', s.toList());
    notifyListeners();
  }

  String get player {
    final v = _b.get('player', defaultValue: 'internal') as String; // internal|mx|chooser|custom
    return v == 'ytv' ? 'internal' : v; // تمت إزالة YTV
  }
  void setPlayer(String v) { _b.put('player', v); notifyListeners(); }
  String get customPackage => _b.get('customPackage', defaultValue: '') as String;
  void setCustomPackage(String v) { _b.put('customPackage', v.trim()); notifyListeners(); }
  String get uiStyle => _b.get('uiStyle', defaultValue: 'classic') as String; // classic|modern
  void setUiStyle(String v) { _b.put('uiStyle', v); notifyListeners(); }

  bool get autoSync => _b.get('autoSync', defaultValue: true) as bool;
  void setAutoSync(bool v) { _b.put('autoSync', v); notifyListeners(); }
}
